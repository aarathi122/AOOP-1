package com.booking.platform;

public interface Observer {
	
	    void update(Event event);
	}



