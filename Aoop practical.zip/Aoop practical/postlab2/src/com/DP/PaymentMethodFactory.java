package com.DP;

public interface PaymentMethodFactory {
    PaymentMethod createPaymentMethod();
}
