package com.DP;

public interface VehicleFactory {
    Vehicle createVehicle();
}
