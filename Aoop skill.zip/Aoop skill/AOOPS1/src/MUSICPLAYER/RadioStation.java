package MUSICPLAYER;

public class RadioStation {
	public void playRadio() {
    System.out.println("Playing music from radio station.");
    }
}
