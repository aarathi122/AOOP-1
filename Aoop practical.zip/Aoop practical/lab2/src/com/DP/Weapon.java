package com.DP;

public interface Weapon {
    void use();
}
