package com.DP;

public interface Vehicle {
    void requestRide();
}
