package com.DP;

public class DaggerWeapon implements Weapon {
    @Override
    public void use() {
        System.out.println("Dagger weapon used!");
    }

}
