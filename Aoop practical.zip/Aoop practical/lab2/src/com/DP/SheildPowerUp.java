package com.DP;

public class SheildPowerUp implements PowerUp {
    @Override
    public void activate() {
        System.out.println("Sheild power-up activated");
    }

}
