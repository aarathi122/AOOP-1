package com.DP;

public class Bike implements Vehicle {
    @Override
    public void requestRide() {
        System.out.println("Requesting a Bike ride!!!");
    }
}