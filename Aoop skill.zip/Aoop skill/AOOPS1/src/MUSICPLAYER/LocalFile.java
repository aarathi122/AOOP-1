package MUSICPLAYER;

public class LocalFile {
	 public void playFile() {
	        System.out.println("Playing music from local file.");
	    }
}
