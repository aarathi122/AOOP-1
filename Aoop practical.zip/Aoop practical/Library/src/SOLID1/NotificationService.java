package SOLID1;

public interface NotificationService {
	void notify(String message);
}
