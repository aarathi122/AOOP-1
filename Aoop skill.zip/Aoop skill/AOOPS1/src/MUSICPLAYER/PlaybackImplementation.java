package MUSICPLAYER;

public interface PlaybackImplementation {
	  void play();
}
