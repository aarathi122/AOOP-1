package com.DP;

public class Car implements Vehicle {
    @Override
    public void requestRide() {
        System.out.println("Requesting a Car Ride!!!");
    }
}
