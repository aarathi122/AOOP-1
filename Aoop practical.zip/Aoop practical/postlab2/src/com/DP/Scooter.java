package com.DP;

public class Scooter implements Vehicle {
    @Override
    public void requestRide() {
        System.out.println("Requesting a Scooter ride!!!");
    }
}